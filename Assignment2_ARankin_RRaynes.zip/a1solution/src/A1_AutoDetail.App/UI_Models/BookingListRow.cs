﻿namespace A1_AutoDetail.App.UI_Models;

public sealed class BookingListRow
{
    public string CustomerName { get; set; } = "";
    public string DetailServiceName { get; set; } = "";
    public string StartTimeText { get; set; } = "";
}

