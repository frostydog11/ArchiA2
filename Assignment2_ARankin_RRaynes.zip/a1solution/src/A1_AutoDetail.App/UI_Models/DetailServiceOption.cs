﻿namespace A1_AutoDetail.App.UI_Models;

public sealed class DetailServiceOption
{
    public int DetailServiceId { get; set; }
    public string DetailServiceName { get; set; } = "";
    public bool IsPremium { get; set; }
}

