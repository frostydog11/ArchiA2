﻿namespace A1_AutoDetail.App.UI_Models;

public sealed class TimeSlotOption
{
    public int TimeSlotId { get; set; }
    public string StartTimeText { get; set; } = "";
}
