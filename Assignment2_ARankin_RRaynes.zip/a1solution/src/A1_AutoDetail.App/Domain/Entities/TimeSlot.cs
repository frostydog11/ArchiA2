namespace A1_AutoDetail.App.Domain.Entities;

public sealed class TimeSlot
{
    public int TimeSlotId { get; set; }
    public DateTime StartTime { get; set; }
}
